const like = document.querySelector('.likes');
const countLikes = document.querySelector(".innerconteiner");

let count = 0;

// <i class="fa fa-heart" aria-hidden="true"></i>
const showHeart=(e)=>{
    const heart = document.createElement('i');
    heart.classList.add("fa");
    heart.classList.add("fa-heart");
    // heart.classList("fa");
    // heart.classList("fa-heart");
    countLikes.appendChild(heart);

    setTimeout(()=>{
        heart.remove();
    },700)
}
countLikes.addEventListener("dblclick",(e)=>{
like.innerHTML = ++count;
showHeart(e)
});